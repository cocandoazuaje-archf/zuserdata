-- ============================================================
-- Script SQL: Crear base de datos 'persona2' y tabla 'persona2'
-- ============================================================

-- Título
SELECT '=== Creación de base de datos y tabla persona2 ===' AS titulo;

-- 1. Crear la base de datos 'persona2' si no existe
CREATE DATABASE IF NOT EXISTS persona2;

-- 2. Seleccionar la base de datos para usar
USE persona2;

-- 3. Crear la tabla 'persona2' si no existe
CREATE TABLE IF NOT EXISTS persona2 (
  id BIGINT NOT NULL AUTO_INCREMENT,  -- Identificador único
  apellido VARCHAR(255),              -- Apellido de la persona
  email VARCHAR(255),                 -- Correo electrónico
  nombre VARCHAR(255),                -- Nombre de la persona
  PRIMARY KEY (id)                    -- Clave primaria
);

-- Confirmación de creación de tabla
SELECT 'Tabla persona2 creada correctamente.' AS mensaje;